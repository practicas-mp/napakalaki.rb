module CombatResult
  WINANDWINGAME = :WINANDWINGAME
  WIN = :WIN
  LOSE = :LOSE
  LOSEANDESCAPE = :LOSEANDESCAPE
  LOSEANDDIE = :LOSEANDDIE
end

module Model

end

Model::CombatResult = CombatResult