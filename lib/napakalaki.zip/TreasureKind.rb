# We'll use this module as an enum for the different types of treasures
# there are
module TreasureKind
  ARMOR = :ARMOR
  ONEHAND = :ONEHAND
  BOTHHANDS = :BOTHHANDS
  HELMET = :HELMET
  SHOE = :SHOE
  NECKLACE = :NECKLACE
end
